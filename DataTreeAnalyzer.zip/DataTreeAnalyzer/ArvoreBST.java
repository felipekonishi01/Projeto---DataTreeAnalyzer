// Projeto de Esturtura de Dados II
// Aplicação 2 - Introdução a ciência de dados usando árvores
//
// Integrantes:
// Felipe Konishi Brum RA: 10417412
// Tiago Teraoka e Sá RA: 10418485

/* Referências
 * 1. "Data Structures and Algorithms in Java" por Robert Lafore
 * 2. "Algorithms" por Robert Sedgewick e Kevin Wayne
 * 3. Documentação oficial do Java: https://docs.oracle.com/en/java/javase/11/docs/api/index.html
 * 4. GeeksforGeeks: https://www.geeksforgeeks.org/
 * 5. Stack Overflow: https://stackoverflow.com/
 */


class ArvoreBST {
    private No raiz;  // raiz da árvore BST
    private int comparacoesInsercao = 0; // contador de comparações para inserção
    private int comparacoesRemocao = 0;  // contador de comparações para remoção

    // insere um novo nó na árvore usando o codIbge como key
    public void inserir(int codIbge, String municipio, String regiaoAdministrativa, int populacao2020,
                        int numEnfermeirosTotais, int numMedicosTotais, int leitosTotal) {
        raiz = inserirRecursivo(raiz, new No(codIbge, municipio, regiaoAdministrativa, populacao2020,
                numEnfermeirosTotais, numMedicosTotais, leitosTotal));
    }

    private No inserirRecursivo(No no, No novoNo) {
        comparacoesInsercao++;  // incrementa para cada comparação de inserção
        if (no == null) {
            return novoNo;
        }
        if (novoNo.codIbge < no.codIbge) {
            no.esquerda = inserirRecursivo(no.esquerda, novoNo);
        } else if (novoNo.codIbge > no.codIbge) {
            no.direita = inserirRecursivo(no.direita, novoNo);
        }
        return no;
    }

    // método de remoção na árvore BST
    public void remover(int codIbge) {
        raiz = removerRecursivo(raiz, codIbge);
    }

    private No removerRecursivo(No no, int codIbge) {
        comparacoesRemocao++;  // incrementa para cada comparação de remoção
        if (no == null) {
            return no;
        }

        if (codIbge < no.codIbge) {
            no.esquerda = removerRecursivo(no.esquerda, codIbge);
        } else if (codIbge > no.codIbge) {
            no.direita = removerRecursivo(no.direita, codIbge);
        } else {
            // nó encontrado: remover
            if (no.esquerda == null) {
                return no.direita;
            } else if (no.direita == null) {
                return no.esquerda;
            }

            // nó com dois filhos
            No menor = encontrarMenorNo(no.direita);
            no.codIbge = menor.codIbge;
            no.direita = removerRecursivo(no.direita, menor.codIbge);
        }
        return no;
    }

    private No encontrarMenorNo(No no) {
        while (no.esquerda != null) {
            no = no.esquerda;
        }
        return no;
    }

    // chamada do método para percorrer recursivamente em ordem
    public void emOrdem() {
        emOrdemRecursivo(raiz);
    }

    // percurso em ordem recursivo
    private void emOrdemRecursivo(No no) {
        if (no != null) {
            emOrdemRecursivo(no.esquerda);
            System.out.println(no.codIbge + ": " + no.municipio);
            emOrdemRecursivo(no.direita);
        }
    }

    // busca um nó pela key do nó
    public No buscar(int codIbge) {
        return buscarRecursivo(raiz, codIbge);
    }

    // busca recursiva com base no codIbge
    private No buscarRecursivo(No no, int codIbge) {
        comparacoesInsercao++;  // também incrementa ao buscar durante a inserção
        if (no == null || no.codIbge == codIbge) {
            return no;
        }
        if (codIbge < no.codIbge) {
            return buscarRecursivo(no.esquerda, codIbge);
        }
        return buscarRecursivo(no.direita, codIbge);
    }

    // retorna o número de comparações feitas para inserção
    public int getComparacoesInsercao() {
        return comparacoesInsercao;
    }

    // retorna o número de comparações feitas para remoção
    public int getComparacoesRemocao() {
        return comparacoesRemocao;
    }
}