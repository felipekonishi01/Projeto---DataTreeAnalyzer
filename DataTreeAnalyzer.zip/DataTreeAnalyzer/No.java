// Projeto de Esturtura de Dados II
// Aplicação 2 - Introdução a ciência de dados usando árvores
//
// Integrantes:
// Felipe Konishi Brum RA: 10417412
// Tiago Teraoka e Sá RA: 10418485

/* Referências
 * 1. "Data Structures and Algorithms in Java" por Robert Lafore
 * 2. "Algorithms" por Robert Sedgewick e Kevin Wayne
 * 3. Documentação oficial do Java: https://docs.oracle.com/en/java/javase/11/docs/api/index.html
 * 4. GeeksforGeeks: https://www.geeksforgeeks.org/
 * 5. Stack Overflow: https://stackoverflow.com/
 */




class No {
    int codIbge; //<<--------------- *****KEY DO NÓ***** 
    String municipio;
    String regiaoAdministrativa;
    int populacao2020;
    int numEnfermeirosTotais;
    int numMedicosTotais;
    int leitosTotal;
    No esquerda;  
    No direita; 
    int altura; 
    public No(int codIbge, String municipio, String regiaoAdministrativa, int populacao2020,
               int numEnfermeirosTotais, int numMedicosTotais, int leitosTotal) {
        this.codIbge = codIbge;
        this.municipio = municipio;
        this.regiaoAdministrativa = regiaoAdministrativa;
        this.populacao2020 = populacao2020;
        this.numEnfermeirosTotais = numEnfermeirosTotais;
        this.numMedicosTotais = numMedicosTotais;
        this.leitosTotal = leitosTotal;
        this.esquerda = null; 
        this.direita = null;
        this.altura = 1; //ALTURA INICIA COM 1 ****
    }
}