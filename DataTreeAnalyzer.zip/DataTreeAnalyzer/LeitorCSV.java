// Projeto de Esturtura de Dados II
// Aplicação 2 - Introdução a ciência de dados usando árvores
//
// Integrantes:
// Felipe Konishi Brum RA: 10417412
// Tiago Teraoka e Sá RA: 10418485

/* Referências
 * 1. "Data Structures and Algorithms in Java" por Robert Lafore
 * 2. "Algorithms" por Robert Sedgewick e Kevin Wayne
 * 3. Documentação oficial do Java: https://docs.oracle.com/en/java/javase/11/docs/api/index.html
 * 4. GeeksforGeeks: https://www.geeksforgeeks.org/
 * 5. Stack Overflow: https://stackoverflow.com/
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LeitorCSV {
    public static void lerCSV(String caminhoArquivo, ArvoreBST bst, ArvoreAVL avl) {
        String linha;
        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            br.readLine(); // pular o cabeçalho
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                // extrair os dados do CSV e colocando em variáveis
                int codIbge = Integer.parseInt(dados[0]);
                String municipio = dados[1];
                String regiaoAdministrativa = dados[3];
                int populacao2020 = Integer.parseInt(dados[5]);
                int numEnfermeirosTotais = Integer.parseInt(dados[9]);
                int numMedicosTotais = Integer.parseInt(dados[13]);
                int leitosTotal = Integer.parseInt(dados[15]);
                // inserir os dados nas duas árvores (BST e AVL)
                bst.inserir(codIbge, municipio, regiaoAdministrativa, populacao2020, numEnfermeirosTotais, numMedicosTotais, leitosTotal);
                avl.inserir(codIbge, municipio, regiaoAdministrativa, populacao2020, numEnfermeirosTotais, numMedicosTotais, leitosTotal);
            }

            // Exibir comparações de desempenho
            System.out.println("Comparações de Inserção:");
            System.out.println("BST: " + bst.getComparacoesInsercao());
            System.out.println("AVL: " + avl.getComparacoesInsercao());

            System.out.println("Comparações de Remoção:");
            System.out.println("BST: " + bst.getComparacoesRemocao());
            System.out.println("AVL: " + avl.getComparacoesRemocao());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void exibirPioresMunicipios() {
        // Processar os dados do arquivo CSV para usar as colunas enf_por_hab e med_por_hab
        try (BufferedReader br = new BufferedReader(new FileReader("dataset.csv"))) {
            br.readLine(); // Ignorar cabeçalho
            List<String[]> municipios = new ArrayList<>();
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                String municipio = dados[1];
                double enfPorHab = Double.parseDouble(dados[10].replace(",", ".")); // Substituir vírgula por ponto
                double medPorHab = Double.parseDouble(dados[14].replace(",", ".")); // Substituir vírgula por ponto
                double totalPorHab = enfPorHab + medPorHab;
                municipios.add(new String[]{municipio, String.format("%.2f", totalPorHab)});
            }

            municipios.sort((a, b) -> Double.compare(Double.parseDouble(a[1]), Double.parseDouble(b[1])));
            System.out.println("Município - Relação Total de Profissionais por Habitante");
            for (int i = 0; i < Math.min(20, municipios.size()); i++) {
                System.out.println(municipios.get(i)[0] + " - " + municipios.get(i)[1]);
            }
        } catch (IOException e) {
            System.out.println("Erro ao ler o arquivo CSV: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Erro ao formatar número: " + e.getMessage());
        }
    }
}
