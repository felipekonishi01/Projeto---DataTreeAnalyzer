// Projeto de Esturtura de Dados II
// Aplicação 2 - Introdução a ciência de dados usando árvores
//
// Integrantes:
// Felipe Konishi Brum RA: 10417412
// Tiago Teraoka e Sá RA: 10418485

/* Referências
 * 1. "Data Structures and Algorithms in Java" por Robert Lafore
 * 2. "Algorithms" por Robert Sedgewick e Kevin Wayne
 * 3. Documentação oficial do Java: https://docs.oracle.com/en/java/javase/11/docs/api/index.html
 * 4. GeeksforGeeks: https://www.geeksforgeeks.org/
 * 5. Stack Overflow: https://stackoverflow.com/
 */




class ArvoreAVL {
    private No raiz;
    private int comparacoesInsercao = 0; // contador de comparações para inserção
    private int comparacoesRemocao = 0;  // contador de comparações para remoção

    // insere um novo nó na árvore AVL
    public void inserir(int codIbge, String municipio, String regiaoAdministrativa, int populacao2020,
                        int numEnfermeirosTotais, int numMedicosTotais, int leitosTotal) {
        No novoNo = new No(codIbge, municipio, regiaoAdministrativa, populacao2020,
                numEnfermeirosTotais, numMedicosTotais, leitosTotal);
        raiz = inserirRecursivo(raiz, novoNo);
    }

    private No inserirRecursivo(No no, No novoNo) {
        comparacoesInsercao++;  // incrementa para cada comparação de inserção
        if (no == null) {
            return novoNo;
        }
        if (novoNo.codIbge < no.codIbge) {
            no.esquerda = inserirRecursivo(no.esquerda, novoNo);
        } else if (novoNo.codIbge > no.codIbge) {
            no.direita = inserirRecursivo(no.direita, novoNo);
        }

        // Atualiza a altura do nó
        no.altura = 1 + Math.max(altura(no.esquerda), altura(no.direita));

        // Verifica o balanceamento e realiza rotações se necessário
        int balanceamento = calcularBalanceamento(no);

        if (balanceamento > 1 && novoNo.codIbge < no.esquerda.codIbge) {
            return rotacaoDireita(no);
        }

        if (balanceamento < -1 && novoNo.codIbge > no.direita.codIbge) {
            return rotacaoEsquerda(no);
        }

        if (balanceamento > 1 && novoNo.codIbge > no.esquerda.codIbge) {
            no.esquerda = rotacaoEsquerda(no.esquerda);
            return rotacaoDireita(no);
        }

        if (balanceamento < -1 && novoNo.codIbge < no.direita.codIbge) {
            no.direita = rotacaoDireita(no.direita);
            return rotacaoEsquerda(no);
        }

        return no;
    }

    // método de remoção de um nó na árvore AVL
    public void remover(int codIbge) {
        raiz = removerRecursivo(raiz, codIbge);
    }

    private No removerRecursivo(No no, int codIbge) {
        comparacoesRemocao++;  // incrementa para cada comparação de remoção
        if (no == null) {
            return no;
        }

        if (codIbge < no.codIbge) {
            no.esquerda = removerRecursivo(no.esquerda, codIbge);
        } else if (codIbge > no.codIbge) {
            no.direita = removerRecursivo(no.direita, codIbge);
        } else {
            // Nó encontrado: caso 1 - nó folha ou com 1 filho
            if (no.esquerda == null || no.direita == null) {
                No temp = no.esquerda != null ? no.esquerda : no.direita;
                if (temp == null) {
                    return null;
                } else {
                    return temp;
                }
            }
            // Caso 2: nó com dois filhos
            No temp = encontrarMenorNo(no.direita);
            no.codIbge = temp.codIbge;
            no.direita = removerRecursivo(no.direita, temp.codIbge);
        }

        // Atualiza altura do nó atual
        no.altura = 1 + Math.max(altura(no.esquerda), altura(no.direita));

        // Verificar balanceamento e ajustar rotações 
        int balanceamento = calcularBalanceamento(no);

        // Casos de rotação
        if (balanceamento > 1 && calcularBalanceamento(no.esquerda) >= 0) {
            return rotacaoDireita(no);
        }

        if (balanceamento > 1 && calcularBalanceamento(no.esquerda) < 0) {
            no.esquerda = rotacaoEsquerda(no.esquerda);
            return rotacaoDireita(no);
        }

        if (balanceamento < -1 && calcularBalanceamento(no.direita) <= 0) {
            return rotacaoEsquerda(no);
        }

        if (balanceamento < -1 && calcularBalanceamento(no.direita) > 0) {
            no.direita = rotacaoDireita(no.direita);
            return rotacaoEsquerda(no);
        }

        return no;
    }

    private No encontrarMenorNo(No no) {
        No atual = no;
        while (atual.esquerda != null) {
            atual = atual.esquerda;
        }
        return atual;
    }

    private int altura(No no) {
        if (no == null) {
            return 0;
        }
        return no.altura;
    }

    private int calcularBalanceamento(No no) {
        if (no == null) {
            return 0;
        }
        return altura(no.esquerda) - altura(no.direita);
    }

    private No rotacaoEsquerda(No no) {
        No novoNo = no.direita;
        no.direita = novoNo.esquerda;
        novoNo.esquerda = no;
        no.altura = 1 + Math.max(altura(no.esquerda), altura(no.direita));
        novoNo.altura = 1 + Math.max(altura(novoNo.esquerda), altura(novoNo.direita));
        return novoNo;
    }

    private No rotacaoDireita(No no) {
        No novoNo = no.esquerda;
        no.esquerda = novoNo.direita;
        novoNo.direita = no;
        no.altura = 1 + Math.max(altura(no.esquerda), altura(no.direita));
        novoNo.altura = 1 + Math.max(altura(novoNo.esquerda), altura(novoNo.direita));
        return novoNo;
    }

    public void emOrdem() {
        emOrdemRecursivo(raiz);
    }

    private void emOrdemRecursivo(No no) {
        if (no != null) {
            emOrdemRecursivo(no.esquerda);
            System.out.println(no.codIbge + ": " + no.municipio);
            emOrdemRecursivo(no.direita);
        }
    }

    public int getComparacoesInsercao() {
        return comparacoesInsercao;
    }

    public int getComparacoesRemocao() {
        return comparacoesRemocao;
    }
}