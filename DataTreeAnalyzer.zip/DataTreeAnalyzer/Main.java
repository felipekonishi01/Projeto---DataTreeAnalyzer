// Projeto de Esturtura de Dados II
// Aplicação 2 - Introdução a ciência de dados usando árvores
//
// Integrantes:
// Felipe Konishi Brum RA: 10417412
// Tiago Teraoka e Sá RA: 10418485

/* Referências
 * 1. "Data Structures and Algorithms in Java" por Robert Lafore
 * 2. "Algorithms" por Robert Sedgewick e Kevin Wayne
 * 3. Documentação oficial do Java: https://docs.oracle.com/en/java/javase/11/docs/api/index.html
 * 4. GeeksforGeeks: https://www.geeksforgeeks.org/
 * 5. Stack Overflow: https://stackoverflow.com/
 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArvoreBST bst = new ArvoreBST();
        ArvoreAVL avl = new ArvoreAVL();

        // Inicializar as árvores com dados de um CSV
        LeitorCSV.lerCSV("dataset.csv", bst, avl);

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== MENU ===");
            System.out.println("1. Exibir árvores em ordem");
            System.out.println("2. Remover por codIbge");
            System.out.println("3. Exibir comparações de remoção");
            System.out.println("4. Sair");
            System.out.println("5. Listar 20 piores municípios");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();

            switch (opcao) {


                case 1:
                    System.out.println("\nÁrvore BST em ordem:");
                    bst.emOrdem();
                    System.out.println("\nÁrvore AVL em ordem:");
                    avl.emOrdem();
                    break;

                case 2:
                    System.out.print("\nDigite o codIbge para remover: ");
                    int codIbge = scanner.nextInt();
                    bst.remover(codIbge);
                    avl.remover(codIbge);
                    System.out.println("Removido de ambas as árvores.");
                    break;

                case 3:
                    System.out.println("\nComparações de remoção:");
                    System.out.println("BST: " + bst.getComparacoesRemocao());
                    System.out.println("AVL: " + avl.getComparacoesRemocao());
                    break;

                case 5:
                    System.out.println("\nOs 20 piores municípios com base em número de enfermeiros e médicos por pessoa:");
                    LeitorCSV.exibirPioresMunicipios();
                    break;

                case 4:
                    System.out.println("Encerrando o programa.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }
    }
}